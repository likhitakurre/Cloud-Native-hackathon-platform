# Full Deployment Steps: Docker, Kubernetes, and AWS EKS

This guide explains how to deploy the Cloud Hackathon Platform end to end on AWS using Docker images, Kubernetes on EKS, Terraform, Helm, ECR, RDS, Redis, S3, SQS, and Cognito.

## 0. Prerequisites

Install:

```bash
docker
aws cli
terraform
kubectl
helm
git
node.js
```

Configure AWS credentials:

```bash
aws configure
```

Your AWS identity needs permissions for:

```text
VPC, EKS, ECR, RDS, S3, SQS, ElastiCache, Cognito, IAM, CloudWatch, ACM
```

## 1. Prepare the Project

If using the zip:

```bash
unzip cloud-hackathon-platform-production.zip
cd cloud-hackathon-platform-production
```

If you are already inside the project folder, continue from there.

## 2. Create Terraform State Backend

Create an S3 bucket for Terraform state:

```bash
aws s3 mb s3://YOUR_TERRAFORM_STATE_BUCKET --region ap-south-1
```

Create a DynamoDB table for Terraform state locking:

```bash
aws dynamodb create-table \
  --table-name YOUR_TERRAFORM_LOCK_TABLE \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-south-1
```

Edit:

```text
infra/terraform/envs/prod/backend.tf
```

Replace:

```text
REPLACE_WITH_TERRAFORM_STATE_BUCKET
REPLACE_WITH_TERRAFORM_LOCK_TABLE
```

## 3. Provision AWS Infrastructure

```bash
cd infra/terraform/envs/prod
cp terraform.tfvars.example terraform.tfvars
terraform init
terraform plan
terraform apply
```

Terraform creates:

```text
VPC
EKS cluster
ECR repositories
S3 submissions bucket
SQS queue and DLQ
RDS PostgreSQL
ElastiCache Redis
Cognito user pool
IAM roles for service accounts
CloudWatch resources
```

After `terraform apply`, view outputs:

```bash
terraform output
```

Save these values:

```text
cluster_name
ecr_repository_urls
submissions_bucket_name
sqs_queue_url
rds_endpoint
redis_endpoint
api_role_arn
worker_role_arn
cognito_issuer
cognito_client_id
cognito_hosted_ui_domain
```

## 4. Connect kubectl to EKS

```bash
aws eks update-kubeconfig \
  --name cloud-hackathon-platform-prod \
  --region ap-south-1
```

Verify:

```bash
kubectl get nodes
```

## 5. Install Kubernetes Add-ons

Add Helm repositories:

```bash
helm repo add eks https://aws.github.io/eks-charts
helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server/
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
```

Install metrics-server:

```bash
helm upgrade --install metrics-server metrics-server/metrics-server \
  --namespace kube-system
```

Install KEDA:

```bash
helm upgrade --install keda kedacore/keda \
  --namespace keda \
  --create-namespace
```

Install AWS Load Balancer Controller using the AWS-recommended IAM role for service account setup for your EKS cluster.

You may also install:

```text
External Secrets Operator
Prometheus Operator
Cluster Autoscaler or Karpenter
CloudWatch Observability add-on
```

## 6. Create Runtime Kubernetes Secret

Create namespace:

```bash
kubectl create namespace hackathon
```

Create secrets:

```bash
kubectl create secret generic platform-secrets \
  --namespace hackathon \
  --from-literal=DATABASE_URL='postgres://USER:PASSWORD@RDS_ENDPOINT:5432/hackathon' \
  --from-literal=REDIS_URL='rediss://REDIS_ENDPOINT:6379'
```

Replace:

```text
USER
PASSWORD
RDS_ENDPOINT
REDIS_ENDPOINT
```

with your real production values.

For a stronger production setup, use AWS Secrets Manager plus External Secrets Operator instead of manual Kubernetes secrets.

## 7. Run Database Migrations

From the project root:

```bash
DATABASE_URL='postgres://USER:PASSWORD@RDS_ENDPOINT:5432/hackathon' \
npm run --prefix services/api migrate
```

PowerShell:

```powershell
$env:DATABASE_URL="postgres://USER:PASSWORD@RDS_ENDPOINT:5432/hackathon"
npm run --prefix services/api migrate
```

## 8. Build Docker Images

From the project root:

```bash
export AWS_REGION=ap-south-1
export AWS_ACCOUNT_ID=YOUR_AWS_ACCOUNT_ID
export IMAGE_TAG=$(git rev-parse --short HEAD)
```

If you are not using Git:

```bash
export IMAGE_TAG=v1
```

Build all production images:

```bash
make build-images AWS_ACCOUNT_ID=$AWS_ACCOUNT_ID IMAGE_TAG=$IMAGE_TAG
```

This builds:

```text
cloud-hackathon-platform-prod-frontend
cloud-hackathon-platform-prod-api
cloud-hackathon-platform-prod-worker
```

## 9. Push Docker Images to ECR

```bash
make push-images AWS_ACCOUNT_ID=$AWS_ACCOUNT_ID IMAGE_TAG=$IMAGE_TAG
```

Images are pushed to:

```text
YOUR_ACCOUNT_ID.dkr.ecr.ap-south-1.amazonaws.com/cloud-hackathon-platform-prod-frontend
YOUR_ACCOUNT_ID.dkr.ecr.ap-south-1.amazonaws.com/cloud-hackathon-platform-prod-api
YOUR_ACCOUNT_ID.dkr.ecr.ap-south-1.amazonaws.com/cloud-hackathon-platform-prod-worker
```

## 10. Configure Helm Production Values

Edit:

```text
deploy/helm/cloud-hackathon-platform/values-prod.yaml
```

Set:

```yaml
global:
  imageRegistry: "YOUR_ACCOUNT_ID.dkr.ecr.ap-south-1.amazonaws.com"
  imageTag: "YOUR_IMAGE_TAG"

config:
  s3Bucket: "YOUR_S3_BUCKET_NAME"
  sqsQueueUrl: "YOUR_SQS_QUEUE_URL"
  cognitoIssuer: "YOUR_COGNITO_ISSUER"
  cognitoClientId: "YOUR_COGNITO_CLIENT_ID"
  cognitoDomain: "YOUR_COGNITO_HOSTED_UI_DOMAIN"

serviceAccounts:
  api:
    annotations:
      eks.amazonaws.com/role-arn: YOUR_API_ROLE_ARN
  worker:
    annotations:
      eks.amazonaws.com/role-arn: YOUR_WORKER_ROLE_ARN

ingress:
  host: your-domain.com
  certificateArn: YOUR_ACM_CERTIFICATE_ARN
```

## 11. Deploy to Kubernetes with Helm

```bash
helm upgrade --install cloud-hackathon-platform \
  ./deploy/helm/cloud-hackathon-platform \
  --namespace hackathon \
  --create-namespace \
  -f ./deploy/helm/cloud-hackathon-platform/values-prod.yaml \
  --set global.imageTag=$IMAGE_TAG \
  --wait
```

## 12. Verify Deployment

```bash
kubectl get pods -n hackathon
kubectl get svc -n hackathon
kubectl get ingress -n hackathon
kubectl get hpa -n hackathon
kubectl get scaledobject -n hackathon
```

Check logs:

```bash
kubectl logs -n hackathon deploy/frontend
kubectl logs -n hackathon deploy/api
kubectl logs -n hackathon deploy/worker
```

Describe resources if something is not running:

```bash
kubectl describe pod -n hackathon POD_NAME
kubectl describe ingress -n hackathon
kubectl get events -n hackathon --sort-by=.metadata.creationTimestamp
```

## 13. Configure DNS

Get ALB hostname:

```bash
kubectl get ingress -n hackathon
```

Point your domain, for example:

```text
hackathon.example.com
```

to the ALB DNS name using Route 53 CNAME or Alias record.

## 14. Configure Cognito Admin Access

In AWS Cognito:

1. Open the created User Pool.
2. Create or invite users.
3. Add admin users to the `Admins` group.
4. Only users in `Admins` can create contests and problems.

Participants do not need the `Admins` group.

## 15. Open the Platform

Visit:

```text
https://your-domain.com
```

Expected flow:

```text
Frontend loads
User signs in with Cognito
Participant views contests/problems
Participant submits code
API uploads code to S3
API sends job to SQS
Worker consumes SQS
Worker judges submission
Worker updates RDS and Redis
Frontend receives live SSE update
Leaderboard refreshes
```

## 16. Optional: Enable Prometheus ServiceMonitor

If Prometheus Operator is installed, edit Helm values:

```yaml
observability:
  serviceMonitor:
    enabled: true
```

Then upgrade:

```bash
helm upgrade --install cloud-hackathon-platform \
  ./deploy/helm/cloud-hackathon-platform \
  --namespace hackathon \
  -f ./deploy/helm/cloud-hackathon-platform/values-prod.yaml \
  --set global.imageTag=$IMAGE_TAG \
  --wait
```

## 17. Optional: Enable gVisor RuntimeClass

Only do this after installing gVisor/containerd support on EKS worker nodes.

Set:

```yaml
worker:
  sandbox:
    runtimeClassName: runsc
    readOnlyRootFilesystem: true
```

If gVisor is not installed and you set `runtimeClassName: runsc`, worker pods will remain pending.

## Useful Debug Commands

```bash
kubectl logs -n hackathon deploy/api -f
kubectl logs -n hackathon deploy/worker -f
kubectl logs -n hackathon deploy/frontend -f
kubectl port-forward -n hackathon svc/api 8080:80
curl http://localhost:8080/health
curl http://localhost:8080/metrics
```

## Deployment Summary

```text
Terraform creates AWS infrastructure
Docker builds frontend/API/worker images
ECR stores images
kubectl connects to EKS
Helm deploys workloads
ALB exposes frontend and API
Cognito handles login
SQS buffers submissions
Workers judge submissions
RDS stores state
Redis stores leaderboard
SSE sends live updates to frontend
```

