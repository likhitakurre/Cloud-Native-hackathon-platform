terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.50"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}

data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  name = "${var.project_name}-${var.environment}"
  azs  = slice(data.aws_availability_zones.available.names, 0, 3)
}

module "network" {
  source = "../../modules/network"

  name               = local.name
  vpc_cidr           = var.vpc_cidr
  availability_zones = local.azs
}

module "ecr" {
  source = "../../modules/ecr"

  name         = local.name
  repositories = ["api", "worker", "frontend"]
}

module "storage" {
  source = "../../modules/storage"

  name = local.name
}

module "queue" {
  source = "../../modules/queue"

  name                       = local.name
  visibility_timeout_seconds = 120
}

module "auth" {
  source = "../../modules/auth"

  name          = local.name
  callback_urls = [var.app_url]
  logout_urls   = [var.app_url]
}

module "database" {
  source = "../../modules/database"

  name                   = local.name
  vpc_id                 = module.network.vpc_id
  private_subnet_ids     = module.network.private_subnet_ids
  app_security_group_id  = module.eks.node_security_group_id
  db_instance_class      = var.db_instance_class
  db_allocated_storage   = var.db_allocated_storage
  db_username            = var.db_username
  db_name                = var.db_name
  backup_retention_period = var.db_backup_retention_period
  multi_az                = var.db_multi_az
  deletion_protection     = var.db_deletion_protection
}

module "cache" {
  source = "../../modules/cache"

  name                  = local.name
  vpc_id                = module.network.vpc_id
  private_subnet_ids    = module.network.private_subnet_ids
  app_security_group_id = module.eks.node_security_group_id
  node_type             = var.redis_node_type
}

module "eks" {
  source = "../../modules/eks"

  name                    = local.name
  kubernetes_version      = var.kubernetes_version
  vpc_id                  = module.network.vpc_id
  private_subnet_ids      = module.network.private_subnet_ids
  public_subnet_ids       = module.network.public_subnet_ids
  node_instance_types     = var.node_instance_types
  min_nodes               = var.min_nodes
  desired_nodes           = var.desired_nodes
  max_nodes               = var.max_nodes
  oidc_provider_audience  = "sts.amazonaws.com"
}

module "irsa" {
  source = "../../modules/irsa"

  name               = local.name
  oidc_provider_arn  = module.eks.oidc_provider_arn
  oidc_provider_url  = module.eks.oidc_provider_url
  namespace          = var.kubernetes_namespace
  api_service_account    = "hackathon-api"
  worker_service_account = "hackathon-worker"
  submissions_bucket_arn = module.storage.submissions_bucket_arn
  queue_arn              = module.queue.queue_arn
  dlq_arn                = module.queue.dlq_arn
}

module "observability" {
  source = "../../modules/observability"

  name              = local.name
  log_retention_days = var.log_retention_days
  queue_name        = module.queue.queue_name
  dlq_name          = module.queue.dlq_name
}
