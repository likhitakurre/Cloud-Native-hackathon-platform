data "aws_iam_policy_document" "api_assume" {
  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [var.oidc_provider_arn]
    }

    condition {
      test     = "StringEquals"
      variable = "${var.oidc_provider_url}:sub"
      values   = ["system:serviceaccount:${var.namespace}:${var.api_service_account}"]
    }
  }
}

data "aws_iam_policy_document" "worker_assume" {
  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [var.oidc_provider_arn]
    }

    condition {
      test     = "StringEquals"
      variable = "${var.oidc_provider_url}:sub"
      values   = ["system:serviceaccount:${var.namespace}:${var.worker_service_account}"]
    }
  }
}

resource "aws_iam_role" "api" {
  name               = "${var.name}-api-irsa"
  assume_role_policy = data.aws_iam_policy_document.api_assume.json
}

resource "aws_iam_role" "worker" {
  name               = "${var.name}-worker-irsa"
  assume_role_policy = data.aws_iam_policy_document.worker_assume.json
}

data "aws_iam_policy_document" "api" {
  statement {
    actions = ["s3:PutObject", "s3:GetObject"]
    resources = [
      "${var.submissions_bucket_arn}/submissions/*",
      "${var.submissions_bucket_arn}/problems/*"
    ]
  }

  statement {
    actions = ["sqs:SendMessage", "sqs:GetQueueAttributes"]
    resources = [var.queue_arn]
  }
}

data "aws_iam_policy_document" "worker" {
  statement {
    actions = ["s3:GetObject", "s3:PutObject"]
    resources = [
      "${var.submissions_bucket_arn}/submissions/*",
      "${var.submissions_bucket_arn}/problems/*",
      "${var.submissions_bucket_arn}/results/*"
    ]
  }

  statement {
    actions = [
      "sqs:ReceiveMessage",
      "sqs:DeleteMessage",
      "sqs:ChangeMessageVisibility",
      "sqs:GetQueueAttributes"
    ]
    resources = [var.queue_arn]
  }
}

resource "aws_iam_policy" "api" {
  name   = "${var.name}-api"
  policy = data.aws_iam_policy_document.api.json
}

resource "aws_iam_policy" "worker" {
  name   = "${var.name}-worker"
  policy = data.aws_iam_policy_document.worker.json
}

resource "aws_iam_role_policy_attachment" "api" {
  role       = aws_iam_role.api.name
  policy_arn = aws_iam_policy.api.arn
}

resource "aws_iam_role_policy_attachment" "worker" {
  role       = aws_iam_role.worker.name
  policy_arn = aws_iam_policy.worker.arn
}
