import client from "prom-client";

client.collectDefaultMetrics();

const httpRequestDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5]
});

const submissionsCreated = new client.Counter({
  name: "submissions_created_total",
  help: "Total submissions accepted by the API",
  labelNames: ["contest_id", "language"]
});

export function observeHttp(req, res, next) {
  const end = httpRequestDuration.startTimer();
  res.on("finish", () => {
    end({
      method: req.method,
      route: req.route?.path || req.path,
      status: String(res.statusCode)
    });
  });
  next();
}

export function recordSubmission(contestId, language) {
  submissionsCreated.inc({ contest_id: contestId, language });
}

export async function metricsResponse(_req, res) {
  res.set("Content-Type", client.register.contentType);
  res.end(await client.register.metrics());
}

