const config = window.__APP_CONFIG__ || {};

function decodeClaims(token) {
  const [, payload] = token.split(".");
  const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), "=");
  return JSON.parse(atob(padded));
}

function randomString(length = 48) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function sha256(value) {
  const encoded = new TextEncoder().encode(value);
  const hash = await crypto.subtle.digest("SHA-256", encoded);
  return btoa(String.fromCharCode(...new Uint8Array(hash)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

export function getStoredAuth() {
  const raw = localStorage.getItem("auth");
  if (!raw) return null;
  const auth = JSON.parse(raw);
  if (!auth.id_token) return null;
  const claims = decodeClaims(auth.id_token);
  if (claims.exp * 1000 < Date.now()) return null;
  return { ...auth, claims };
}

export async function beginLogin() {
  const verifier = randomString();
  const challenge = await sha256(verifier);
  sessionStorage.setItem("pkceVerifier", verifier);
  const params = new URLSearchParams({
    client_id: config.cognitoClientId,
    response_type: "code",
    scope: "openid email profile",
    redirect_uri: window.location.origin,
    code_challenge_method: "S256",
    code_challenge: challenge
  });
  window.location.href = `${config.cognitoDomain}/oauth2/authorize?${params.toString()}`;
}

export async function completeLoginIfNeeded() {
  const url = new URL(window.location.href);
  const code = url.searchParams.get("code");
  if (!code) return getStoredAuth();

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: config.cognitoClientId,
    redirect_uri: window.location.origin,
    code,
    code_verifier: sessionStorage.getItem("pkceVerifier")
  });
  const response = await fetch(`${config.cognitoDomain}/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  const tokens = await response.json();
  localStorage.setItem("auth", JSON.stringify(tokens));
  window.history.replaceState({}, document.title, window.location.pathname);
  return getStoredAuth();
}

export function logout() {
  localStorage.removeItem("auth");
  const params = new URLSearchParams({
    client_id: config.cognitoClientId,
    logout_uri: window.location.origin
  });
  window.location.href = `${config.cognitoDomain}/logout?${params.toString()}`;
}

export const appConfig = config;

