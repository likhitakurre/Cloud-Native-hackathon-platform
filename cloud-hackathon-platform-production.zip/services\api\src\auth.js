import { createRemoteJWKSet, jwtVerify } from "jose";
import { query } from "./db.js";

const issuer = process.env.COGNITO_ISSUER;
const clientId = process.env.COGNITO_CLIENT_ID;
const authDisabled = process.env.AUTH_DISABLED === "true" || !issuer || !clientId;
const jwks = authDisabled ? null : createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));

function roleFromClaims(claims) {
  const groups = claims["cognito:groups"] || [];
  if (groups.includes("Admins")) return "ADMIN";
  if (groups.includes("Judges")) return "JUDGE";
  return "PARTICIPANT";
}

export async function requireAuth(req, res, next) {
  if (authDisabled) {
    const userId = req.header("x-user-id");
    if (userId) {
      req.user = { id: userId, role: req.header("x-user-role") || "PARTICIPANT" };
      next();
      return;
    }
    res.status(401).json({ error: "Authentication is required" });
    return;
  }

  const authorization = req.header("authorization") || "";
  const token = authorization.startsWith("Bearer ") ? authorization.slice("Bearer ".length) : "";
  if (!token) {
    res.status(401).json({ error: "Bearer token is required" });
    return;
  }

  try {
    const { payload } = await jwtVerify(token, jwks, {
      issuer,
      audience: clientId
    });
    const email = payload.email || payload.username || payload.sub;
    const name = payload.name || email;
    const role = roleFromClaims(payload);
    const [user] = await query(
      `INSERT INTO users (external_subject, name, email, role)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (external_subject) DO UPDATE
       SET name = EXCLUDED.name, email = EXCLUDED.email, role = EXCLUDED.role
       RETURNING id, name, email, role`,
      [payload.sub, name, email, role]
    );
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      res.status(403).json({ error: "Insufficient permissions" });
      return;
    }
    next();
  };
}

