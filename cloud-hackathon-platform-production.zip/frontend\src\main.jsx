import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity,
  BookOpen,
  Code2,
  LayoutDashboard,
  ListChecks,
  Play,
  Plus,
  RefreshCcw,
  Shield,
  Trophy,
  UserRound
} from "lucide-react";
import "./styles.css";
import { appConfig, beginLogin, completeLoginIfNeeded, getStoredAuth, logout } from "./auth.js";

const apiBase = appConfig.apiBase || "/api";
const defaultCode = `n = int(input())
print(n * 2)
`;
const defaultTests = JSON.stringify([
  { input: "2\n", output: "4\n" },
  { input: "7\n", output: "14\n" }
], null, 2);

async function request(path, options = {}) {
  const auth = getStoredAuth();
  const response = await fetch(`${apiBase}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(auth?.id_token ? { Authorization: `Bearer ${auth.id_token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Request failed: ${response.status}`);
  }
  return data;
}

function usePolling(callback, delay, deps) {
  useEffect(() => {
    callback();
    const timer = setInterval(callback, delay);
    return () => clearInterval(timer);
  }, deps);
}

function App() {
  const [view, setView] = useState("participant");
  const [auth, setAuth] = useState(() => getStoredAuth());
  const [user, setUser] = useState(null);
  const [contests, setContests] = useState([]);
  const [contestId, setContestId] = useState("");
  const [problems, setProblems] = useState([]);
  const [problemId, setProblemId] = useState("");
  const [language, setLanguage] = useState("python");
  const [code, setCode] = useState(defaultCode);
  const [leaderboard, setLeaderboard] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [stats, setStats] = useState(null);
  const [message, setMessage] = useState("");
  const [adminContest, setAdminContest] = useState({
    title: "",
    description: "",
    startsAt: "",
    endsAt: ""
  });
  const [adminProblem, setAdminProblem] = useState({
    title: "",
    statement: "",
    timeLimitMs: 2000,
    memoryLimitMb: 256,
    tests: defaultTests
  });

  const selectedContest = useMemo(
    () => contests.find((contest) => contest.id === contestId),
    [contests, contestId]
  );
  const selectedProblem = useMemo(
    () => problems.find((problem) => problem.id === problemId),
    [problems, problemId]
  );

  async function loadContests() {
    const rows = await request("/contests");
    setContests(rows);
    if (!contestId && rows[0]) setContestId(rows[0].id);
  }

  async function loadProblems(id = contestId) {
    if (!id) return;
    const rows = await request(`/contests/${id}/problems`);
    setProblems(rows);
    if (!rows.some((problem) => problem.id === problemId)) {
      setProblemId(rows[0]?.id || "");
    }
  }

  async function loadLeaderboard(id = contestId) {
    if (!id) return;
    setLeaderboard(await request(`/contests/${id}/leaderboard`));
  }

  async function loadSubmissions() {
    if (!user || !contestId) return;
    setSubmissions(await request(`/submissions?contestId=${contestId}&userId=${user.id}`));
  }

  async function loadStats() {
    if (!getStoredAuth()) return;
    setStats(await request("/platform/stats"));
  }

  async function submitCode() {
    setMessage("Submitting code...");
    const result = await request("/submissions", {
      method: "POST",
      body: JSON.stringify({ contestId, problemId, language, code })
    });
    setMessage(`Submission queued: ${result.submissionId}`);
    await loadSubmissions();
  }

  async function createContest(event) {
    event.preventDefault();
    const created = await request("/admin/contests", {
      method: "POST",
      body: JSON.stringify(adminContest)
    });
    setAdminContest({ title: "", description: "", startsAt: "", endsAt: "" });
    setContestId(created.id);
    await loadContests();
    setMessage("Contest created.");
  }

  async function createProblem(event) {
    event.preventDefault();
    const tests = JSON.parse(adminProblem.tests);
    await request("/admin/problems", {
      method: "POST",
      body: JSON.stringify({
        contestId,
        title: adminProblem.title,
        statement: adminProblem.statement,
        timeLimitMs: Number(adminProblem.timeLimitMs),
        memoryLimitMb: Number(adminProblem.memoryLimitMb),
        tests
      })
    });
    setAdminProblem({ title: "", statement: "", timeLimitMs: 2000, memoryLimitMb: 256, tests: defaultTests });
    await loadProblems();
    setMessage("Problem created and tests uploaded.");
  }

  useEffect(() => {
    completeLoginIfNeeded()
      .then(async (nextAuth) => {
        setAuth(nextAuth);
        if (nextAuth) {
          setUser(await request("/me"));
          await loadStats();
        }
      })
      .catch((error) => setMessage(error.message));
    loadContests().catch((error) => setMessage(error.message));
  }, []);

  useEffect(() => {
    const source = new EventSource(`${apiBase}/events`);
    source.addEventListener("platform", () => {
      loadLeaderboard().catch(() => {});
      loadSubmissions().catch(() => {});
      loadStats().catch(() => {});
      loadContests().catch(() => {});
    });
    return () => source.close();
  }, [contestId, user?.id]);

  useEffect(() => {
    loadProblems().catch((error) => setMessage(error.message));
    loadLeaderboard().catch(() => {});
  }, [contestId]);

  usePolling(() => {
    loadLeaderboard().catch(() => {});
    loadSubmissions().catch(() => {});
  }, 3000, [contestId, user?.id]);

  return (
    <main className="app">
      <aside className="sidebar">
        <div className="brand">
          <Code2 size={26} />
          <div>
            <strong>Cloud Hackathon</strong>
            <span>AWS EKS Judge Platform</span>
          </div>
        </div>
        <button className={view === "participant" ? "nav active" : "nav"} onClick={() => setView("participant")}>
          <LayoutDashboard size={18} /> Participant
        </button>
        <button className={view === "admin" ? "nav active" : "nav"} onClick={() => setView("admin")}>
          <Shield size={18} /> Admin
        </button>
        <button className="nav" onClick={() => { loadContests(); loadProblems(); }}>
          <RefreshCcw size={18} /> Refresh
        </button>
      </aside>

      <section className="content">
        <header className="topbar">
          <div>
            <p className="eyebrow">Production Contest Console</p>
            <h1>{selectedContest?.title || "Create or select a contest"}</h1>
          </div>
          {user ? (
            <div className="userPill">
              <UserRound size={18} />
              <span>{user.name}</span>
              <button className="linkButton" onClick={logout}>Logout</button>
            </div>
          ) : null}
        </header>

        {message ? <div className="notice">{message}</div> : null}

        {!auth ? (
          <section className="panel narrow">
            <h2><UserRound size={20} /> Sign in</h2>
            <p>Use the Cognito hosted login to access contests, submit code, and manage admin workflows.</p>
            <button className="primary" onClick={beginLogin}><UserRound size={18} /> Sign in with Cognito</button>
          </section>
        ) : view === "participant" ? (
          <section className="grid">
            <div className="mainColumn">
              <section className="panel">
                <div className="panelHeader">
                  <h2><BookOpen size={20} /> Contest Problem</h2>
                  <select value={contestId} onChange={(event) => setContestId(event.target.value)}>
                    {contests.map((contest) => <option key={contest.id} value={contest.id}>{contest.title}</option>)}
                  </select>
                </div>
                <select className="wide" value={problemId} onChange={(event) => setProblemId(event.target.value)}>
                  {problems.map((problem) => <option key={problem.id} value={problem.id}>{problem.title}</option>)}
                </select>
                <p>{selectedProblem?.statement || "No problem selected."}</p>
                {selectedProblem ? <div className="limits"><span>{selectedProblem.time_limit_ms} ms</span><span>{selectedProblem.memory_limit_mb} MB</span></div> : null}
              </section>

              <section className="panel editorPanel">
                <div className="panelHeader">
                  <h2><Code2 size={20} /> Submission Editor</h2>
                  <div className="actions">
                    <select value={language} onChange={(event) => setLanguage(event.target.value)}>
                      <option value="python">Python</option>
                      <option value="javascript">JavaScript</option>
                    </select>
                    <button className="primary" onClick={submitCode} disabled={!contestId || !problemId}>
                      <Play size={18} /> Submit
                    </button>
                  </div>
                </div>
                <textarea className="code" value={code} onChange={(event) => setCode(event.target.value)} spellCheck="false" />
              </section>
            </div>

            <aside className="sideColumn">
              <Leaderboard rows={leaderboard} />
              <StatsPanel stats={stats} />
              <SubmissionList rows={submissions} />
            </aside>
          </section>
        ) : (
          <section className="grid">
            <div className="mainColumn">
              <section className="panel">
                <h2><Plus size={20} /> Create Contest</h2>
                <form onSubmit={createContest} className="formGrid">
                  <label>Title<input value={adminContest.title} onChange={(event) => setAdminContest({ ...adminContest, title: event.target.value })} required /></label>
                  <label>Description<textarea value={adminContest.description} onChange={(event) => setAdminContest({ ...adminContest, description: event.target.value })} required /></label>
                  <label>Starts At<input type="datetime-local" value={adminContest.startsAt} onChange={(event) => setAdminContest({ ...adminContest, startsAt: event.target.value })} required /></label>
                  <label>Ends At<input type="datetime-local" value={adminContest.endsAt} onChange={(event) => setAdminContest({ ...adminContest, endsAt: event.target.value })} required /></label>
                  <button className="primary"><Plus size={18} /> Create Contest</button>
                </form>
              </section>

              <section className="panel">
                <h2><ListChecks size={20} /> Create Problem</h2>
                <form onSubmit={createProblem} className="formGrid">
                  <label>Contest<select value={contestId} onChange={(event) => setContestId(event.target.value)}>
                    {contests.map((contest) => <option key={contest.id} value={contest.id}>{contest.title}</option>)}
                  </select></label>
                  <label>Title<input value={adminProblem.title} onChange={(event) => setAdminProblem({ ...adminProblem, title: event.target.value })} required /></label>
                  <label>Statement<textarea value={adminProblem.statement} onChange={(event) => setAdminProblem({ ...adminProblem, statement: event.target.value })} required /></label>
                  <div className="two">
                    <label>Time Limit ms<input type="number" value={adminProblem.timeLimitMs} onChange={(event) => setAdminProblem({ ...adminProblem, timeLimitMs: event.target.value })} /></label>
                    <label>Memory MB<input type="number" value={adminProblem.memoryLimitMb} onChange={(event) => setAdminProblem({ ...adminProblem, memoryLimitMb: event.target.value })} /></label>
                  </div>
                  <label>Tests JSON<textarea className="tests" value={adminProblem.tests} onChange={(event) => setAdminProblem({ ...adminProblem, tests: event.target.value })} required /></label>
                  <button className="primary"><Plus size={18} /> Create Problem</button>
                </form>
              </section>
            </div>
            <aside className="sideColumn">
              <StatsPanel stats={stats} />
              <section className="panel">
                <h2><Activity size={20} /> Active Contests</h2>
                {contests.map((contest) => <div className="contestRow" key={contest.id}><strong>{contest.title}</strong><span>{new Date(contest.ends_at).toLocaleString()}</span></div>)}
              </section>
            </aside>
          </section>
        )}
      </section>
    </main>
  );
}

function Leaderboard({ rows }) {
  return (
    <section className="panel">
      <h2><Trophy size={20} /> Leaderboard</h2>
      {rows.length === 0 ? <p className="muted">No scores yet.</p> : rows.map((row) => (
        <div className="rankRow" key={row.userId}>
          <span>{row.rank}</span>
          <strong>{row.name}</strong>
          <em>{row.score}</em>
        </div>
      ))}
    </section>
  );
}

function SubmissionList({ rows }) {
  return (
    <section className="panel">
      <h2><ListChecks size={20} /> My Submissions</h2>
      {rows.length === 0 ? <p className="muted">No submissions yet.</p> : rows.map((row) => (
        <div className="submissionRow" key={row.id}>
          <strong>{row.status}</strong>
          <span>{row.language} - {row.score} pts</span>
        </div>
      ))}
    </section>
  );
}

function StatsPanel({ stats }) {
  return (
    <section className="panel">
      <h2><Activity size={20} /> Platform Status</h2>
      {!stats ? <p className="muted">Sign in to view platform metrics.</p> : (
        <div className="statsGrid">
          <div><strong>{stats.contests}</strong><span>Contests</span></div>
          <div><strong>{stats.problems}</strong><span>Problems</span></div>
          <div><strong>{stats.submissions}</strong><span>Submissions</span></div>
          <div><strong>{stats.accepted}</strong><span>Accepted</span></div>
          <div><strong>{stats.queueVisible}</strong><span>Queued</span></div>
          <div><strong>{stats.queueInFlight}</strong><span>Running</span></div>
        </div>
      )}
    </section>
  );
}

createRoot(document.getElementById("root")).render(<App />);
