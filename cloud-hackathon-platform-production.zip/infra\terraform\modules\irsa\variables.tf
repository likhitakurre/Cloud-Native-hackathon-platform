variable "name" { type = string }
variable "oidc_provider_arn" { type = string }
variable "oidc_provider_url" { type = string }
variable "namespace" { type = string }
variable "api_service_account" { type = string }
variable "worker_service_account" { type = string }
variable "submissions_bucket_arn" { type = string }
variable "queue_arn" { type = string }
variable "dlq_arn" { type = string }

