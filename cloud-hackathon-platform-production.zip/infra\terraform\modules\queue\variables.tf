variable "name" { type = string }
variable "visibility_timeout_seconds" { type = number }

