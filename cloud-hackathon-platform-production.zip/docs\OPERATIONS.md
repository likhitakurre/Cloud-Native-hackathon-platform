# Operations Runbook

## Health Checks

```bash
kubectl get pods -n hackathon
kubectl get deploy -n hackathon
kubectl get hpa -n hackathon
kubectl get scaledobject -n hackathon
```

## Logs

```bash
kubectl logs -n hackathon deploy/api
kubectl logs -n hackathon deploy/worker
kubectl logs -n hackathon deploy/frontend
```

Application logs are structured JSON and suitable for CloudWatch Logs Insights.

## Real-Time Events

The API exposes an SSE endpoint at:

```text
/api/events
```

Workers publish submission lifecycle events through Redis Pub/Sub. The frontend listens for these events and refreshes submissions/leaderboards.

## Scaling

API pods scale by CPU through HPA.

Worker pods scale by SQS queue depth through KEDA:

```bash
kubectl describe scaledobject worker-sqs -n hackathon
```

For large contests, pre-scale the node group or use Karpenter with warm capacity because EC2 node provisioning is not instant.

## Metrics

The API exposes Prometheus metrics:

```bash
kubectl port-forward -n hackathon svc/api 8080:80
curl http://localhost:8080/metrics
```

## Failure Recovery

- Failed API pods are replaced by Kubernetes.
- Failed worker pods cause SQS messages to reappear after visibility timeout.
- Poison jobs move to DLQ after repeated failures.
- Redis leaderboard can be rebuilt from RDS submission results.
- RDS is Multi-AZ with backups and deletion protection.
