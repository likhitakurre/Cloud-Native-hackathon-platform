# Production Security

## AWS Security

- Use IRSA, not static AWS keys.
- Use Cognito groups for `Admins` and `Judges`; do not trust client-supplied roles.
- Keep RDS and Redis in private subnets.
- Enable RDS deletion protection and encryption.
- Block all public access on S3.
- Use SQS DLQ for poison messages.
- Use ECR immutable tags and scan-on-push.
- Put public APIs behind ALB, ACM TLS, and AWS WAF.

## Kubernetes Security

- Run pods as non-root.
- Drop Linux capabilities.
- Disable privilege escalation.
- Use resource requests and limits.
- Use separate node groups for execution workloads.
- Apply restrictive NetworkPolicies.
- Keep secrets out of Helm values unless encrypted.

## Code Execution Security

The included worker is a production service skeleton. For real untrusted code execution, run each submission in a stronger sandbox such as:

- Kubernetes Job with gVisor RuntimeClass
- Firecracker microVM worker pool
- AWS Batch on isolated compute environments

The Helm chart supports an optional worker runtime class:

```yaml
worker:
  sandbox:
    runtimeClassName: runsc
    readOnlyRootFilesystem: true
```

Only enable `runtimeClassName: runsc` after installing gVisor/containerd support on the EKS worker nodes. Otherwise pods will remain pending.

Minimum sandbox requirements:

- no network egress
- read-only root filesystem
- non-root user
- CPU, memory, process, and time limits
- no hostPath mounts
- no AWS credentials
- no access to Kubernetes API
- isolated temporary filesystem
