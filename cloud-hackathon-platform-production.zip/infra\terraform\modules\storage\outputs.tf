output "submissions_bucket_name" { value = aws_s3_bucket.submissions.bucket }
output "submissions_bucket_arn" { value = aws_s3_bucket.submissions.arn }

