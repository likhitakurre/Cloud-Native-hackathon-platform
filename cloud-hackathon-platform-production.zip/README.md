# Cloud Hackathon Platform: AWS Production Deployment

Production deployment-ready repository for a cloud-based online hackathon and coding contest platform on AWS.

This project includes a deployable browser frontend, API service, judge worker, and AWS infrastructure. It is structured for real AWS deployment using:

- Amazon EKS for Kubernetes workloads
- Amazon ECR for container images
- Amazon RDS PostgreSQL for durable relational data
- Amazon ElastiCache Redis for fast leaderboard state
- Amazon S3 for submissions, artifacts, and test bundles
- Amazon SQS with DLQ for queued judging
- Amazon Cognito for user authentication and admin/judge groups
- IAM Roles for Service Accounts for least-privilege AWS access
- Server-Sent Events for live leaderboard/submission refresh
- Prometheus-compatible API metrics and CloudWatch dashboards
- Helm for Kubernetes release management
- Terraform for AWS infrastructure
- GitHub Actions with OIDC for CI/CD

## Repository Layout

```text
.github/workflows/              Production CI/CD pipeline
database/migrations/            SQL migrations for RDS PostgreSQL
deploy/helm/                    Helm chart for EKS deployments
docs/                           Deployment and security runbooks
infra/terraform/envs/prod/      Production Terraform environment
infra/terraform/modules/        Reusable AWS infrastructure modules
services/api/                   Production API service container
services/worker/                Production judge worker service container
frontend/                       Participant and admin web console
```

## Production Architecture

```text
Internet
  |
  v
AWS ALB + ACM TLS
  |
  v
EKS Ingress
  |
  +--> Frontend Deployment
  |
  +--> API Deployment (/api)
  |      |-- RDS PostgreSQL
  |      |-- S3 submissions bucket
  |      |-- SQS submissions queue
  |
  +--> Worker Deployment
         |-- SQS queue consumer
         |-- S3 code/test artifacts
         |-- RDS result writes
         |-- Redis leaderboard updates

Autoscaling:
  API: Kubernetes HPA
  Worker: KEDA SQS queue-depth scaler
  Nodes: Cluster Autoscaler or Karpenter
```

## Deployment Path

1. Configure Terraform backend in [backend.tf](C:/Users/likhi/Documents/Codex/2026-05-07/you-are-a-senior-cloud-architect-3/infra/terraform/envs/prod/backend.tf).
2. Provision AWS infrastructure with Terraform.
3. Apply database migrations to RDS.
4. Build and push frontend/API/worker images to ECR.
5. Configure [values-prod.yaml](C:/Users/likhi/Documents/Codex/2026-05-07/you-are-a-senior-cloud-architect-3/deploy/helm/cloud-hackathon-platform/values-prod.yaml), including Cognito issuer/client/domain.
6. Deploy the Helm chart to EKS.

Detailed steps are in [docs/DEPLOYMENT.md](C:/Users/likhi/Documents/Codex/2026-05-07/you-are-a-senior-cloud-architect-3/docs/DEPLOYMENT.md).

## Commands

```bash
make terraform-init
make terraform-plan
make terraform-apply

make build-images AWS_ACCOUNT_ID=123456789012 IMAGE_TAG=$(git rev-parse --short HEAD)
make push-images AWS_ACCOUNT_ID=123456789012 IMAGE_TAG=$(git rev-parse --short HEAD)

make helm-template ENV=prod IMAGE_TAG=$(git rev-parse --short HEAD)
```

## Security

Security guidance is in [docs/SECURITY.md](C:/Users/likhi/Documents/Codex/2026-05-07/you-are-a-senior-cloud-architect-3/docs/SECURITY.md).

Important note: the worker service is production-deployable, but real untrusted-code execution should use stronger isolation such as gVisor, Firecracker, or isolated Kubernetes Jobs with no network egress and no AWS credentials.
