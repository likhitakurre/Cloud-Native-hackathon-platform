# Demo Checklist

Use this checklist while presenting.

## Before Demo

- Terraform apply completed
- Helm release installed
- Frontend URL opens
- Cognito user exists
- Admin user is in `Admins` group
- `platform-secrets` exists in Kubernetes
- Database migrations completed
- Seed data loaded if needed

## Commands

```bash
kubectl get pods -n hackathon
kubectl get hpa -n hackathon
kubectl get scaledobject -n hackathon
kubectl get ingress -n hackathon
kubectl logs -n hackathon deploy/api --tail=50
kubectl logs -n hackathon deploy/worker --tail=50
```

## Demo Flow

1. Open frontend.
2. Login with Cognito.
3. Show platform status card.
4. Open admin view.
5. Create contest/problem.
6. Open participant view.
7. Submit accepted code.
8. Submit wrong code.
9. Show leaderboard and submission history.
10. Explain SQS, KEDA, worker autoscaling.

