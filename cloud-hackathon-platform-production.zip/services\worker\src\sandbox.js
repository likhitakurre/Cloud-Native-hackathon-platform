import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";

const timeoutMs = Number(process.env.EXECUTION_TIMEOUT_MS || 2500);
const maxOutputBytes = 64 * 1024;

function commandFor(language, filePath) {
  if (language === "python") return { command: "python3", args: [filePath] };
  if (language === "javascript") return { command: "node", args: [filePath] };
  throw new Error(`Unsupported language: ${language}`);
}

export async function runSubmission({ language, source, input }) {
  const dir = await mkdtemp(path.join(tmpdir(), "judge-"));
  const filename = language === "python" ? "main.py" : "main.js";
  const filePath = path.join(dir, filename);

  try {
    await writeFile(filePath, source, { mode: 0o600 });
    const { command, args } = commandFor(language, filePath);

    return await new Promise((resolve) => {
      const started = Date.now();
      const child = spawn(command, args, {
        cwd: dir,
        stdio: ["pipe", "pipe", "pipe"],
        shell: false,
        env: {
          PATH: process.env.PATH || "",
          NODE_OPTIONS: "--max-old-space-size=128",
          PYTHONUNBUFFERED: "1"
        }
      });

      let stdout = "";
      let stderr = "";
      let timedOut = false;

      const timer = setTimeout(() => {
        timedOut = true;
        child.kill("SIGKILL");
      }, timeoutMs);

      child.stdout.on("data", (chunk) => {
        if (stdout.length < maxOutputBytes) stdout += chunk.toString();
      });

      child.stderr.on("data", (chunk) => {
        if (stderr.length < maxOutputBytes) stderr += chunk.toString();
      });

      child.on("error", (error) => {
        clearTimeout(timer);
        resolve({ verdict: "RUNTIME_ERROR", stdout, stderr: error.message, runtimeMs: Date.now() - started });
      });

      child.on("close", (code) => {
        clearTimeout(timer);
        if (timedOut) {
          resolve({ verdict: "TIME_LIMIT_EXCEEDED", stdout, stderr, runtimeMs: Date.now() - started });
          return;
        }
        if (code !== 0) {
          resolve({ verdict: "RUNTIME_ERROR", stdout, stderr, runtimeMs: Date.now() - started });
          return;
        }
        resolve({ verdict: "OK", stdout, stderr, runtimeMs: Date.now() - started });
      });

      child.stdin.end(input);
    });
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

