variable "aws_region" {
  type    = string
  default = "ap-south-1"
}

variable "project_name" {
  type    = string
  default = "cloud-hackathon-platform"
}

variable "environment" {
  type    = string
  default = "prod"
}

variable "vpc_cidr" {
  type    = string
  default = "10.40.0.0/16"
}

variable "kubernetes_version" {
  type    = string
  default = "1.30"
}

variable "kubernetes_namespace" {
  type    = string
  default = "hackathon"
}

variable "node_instance_types" {
  type    = list(string)
  default = ["t3.micro"]
}

variable "min_nodes" {
  type    = number
  default = 1
}

variable "desired_nodes" {
  type    = number
  default = 1
}

variable "max_nodes" {
  type    = number
  default = 2
}

variable "db_instance_class" {
  type    = string
  default = "db.t3.micro"
}

variable "db_allocated_storage" {
  type    = number
  default = 20
}

variable "db_backup_retention_period" {
  type    = number
  default = 1
}

variable "db_multi_az" {
  type    = bool
  default = false
}

variable "db_deletion_protection" {
  type    = bool
  default = false
}

variable "db_username" {
  type    = string
  default = "hackathon_admin"
}

variable "db_name" {
  type    = string
  default = "hackathon"
}

variable "redis_node_type" {
  type    = string
  default = "cache.t3.micro"
}

variable "log_retention_days" {
  type    = number
  default = 30
}

variable "app_url" {
  type    = string
  default = "https://hackathon.example.com"
}
