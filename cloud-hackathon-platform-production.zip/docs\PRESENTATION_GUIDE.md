# End-Term Presentation Guide

## One-Line Project Pitch

This project is a production-style cloud platform for hosting online coding contests and hackathons on AWS using Docker, Kubernetes on EKS, microservices, SQS-based judging, Redis leaderboards, Cognito authentication, and autoscaling workers.

## What to Show First

1. Open the deployed frontend.
2. Login using Cognito.
3. Show the participant dashboard.
4. Show contest/problem list.
5. Submit code.
6. Show submission moving through queued/running/judged states.
7. Show leaderboard update.
8. Switch to admin user.
9. Create a contest/problem.
10. Explain SQS/KEDA autoscaling.

## Architecture Diagram

```text
Browser
  |
  v
AWS ALB + HTTPS
  |
  v
EKS Ingress
  |
  +--> Frontend Pods
  |
  +--> API Pods
        |-- Cognito JWT validation
        |-- RDS PostgreSQL metadata
        |-- S3 code/test artifacts
        |-- SQS submission queue
        |-- Redis leaderboard/events
  |
  +--> Worker Pods
        |-- consume SQS
        |-- download code/tests from S3
        |-- execute code
        |-- update RDS result
        |-- update Redis leaderboard
        |-- publish SSE event
```

## Key Features to Mention

- Dockerized frontend, API, and worker services
- Kubernetes deployments with readiness/liveness probes
- HPA for API/frontend scaling
- KEDA SQS-based autoscaling for worker pods
- Cognito authentication and admin groups
- S3 storage for submissions and test cases
- SQS decoupling for high concurrency
- RDS for durable relational data
- Redis for fast leaderboard and real-time event fanout
- SSE real-time frontend refresh
- Prometheus `/metrics` endpoint
- CloudWatch dashboard and alarms
- Terraform infrastructure as code
- Helm release management
- GitHub Actions CI/CD

## Demo Code Submission

For the seeded `Double It` problem:

```python
n = int(input())
print(n * 2)
```

Wrong answer example:

```python
n = int(input())
print(n)
```

Time limit example:

```python
while True:
    pass
```

## Talking Point: Why Queue-Based Judging?

If 1000 users submit in one minute, the API does not execute code directly. It stores code in S3, writes metadata to RDS, and pushes jobs to SQS. Worker pods consume from SQS at a controlled rate and autoscale with KEDA. This prevents API overload and gives fault-tolerant retries.

## Talking Point: How Failure Recovery Works

- API pod crash: Kubernetes restarts pod.
- Worker crash: SQS message becomes visible again.
- Repeated worker failure: message goes to DLQ.
- Redis loss: leaderboard can be rebuilt from RDS.
- RDS failure: Multi-AZ failover.

## Final Summary

The project demonstrates cloud architecture, distributed queues, container orchestration, autoscaling, secure identity, and real-time user experience in a single AWS-native platform.

