variable "name" { type = string }
variable "kubernetes_version" { type = string }
variable "vpc_id" { type = string }
variable "private_subnet_ids" { type = list(string) }
variable "public_subnet_ids" { type = list(string) }
variable "node_instance_types" { type = list(string) }
variable "min_nodes" { type = number }
variable "desired_nodes" { type = number }
variable "max_nodes" { type = number }
variable "oidc_provider_audience" { type = string }

