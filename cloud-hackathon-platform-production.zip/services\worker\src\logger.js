export function log(level, message, fields = {}) {
  console.log(JSON.stringify({
    level,
    message,
    service: "worker",
    timestamp: new Date().toISOString(),
    ...fields
  }));
}

