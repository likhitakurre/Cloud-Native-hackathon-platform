export function log(level, message, fields = {}) {
  console.log(JSON.stringify({
    level,
    message,
    service: "api",
    timestamp: new Date().toISOString(),
    ...fields
  }));
}

