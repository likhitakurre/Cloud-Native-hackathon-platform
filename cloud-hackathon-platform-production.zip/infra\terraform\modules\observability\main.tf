resource "aws_cloudwatch_log_group" "api" {
  name              = "/aws/eks/${var.name}/api"
  retention_in_days = var.log_retention_days
}

resource "aws_cloudwatch_log_group" "worker" {
  name              = "/aws/eks/${var.name}/worker"
  retention_in_days = var.log_retention_days
}

resource "aws_cloudwatch_metric_alarm" "worker_dlq" {
  alarm_name          = "${var.name}-submissions-dlq-visible"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "ApproximateNumberOfMessagesVisible"
  namespace           = "AWS/SQS"
  period              = 60
  statistic           = "Sum"
  threshold           = 0
  alarm_description   = "Submissions are landing in the dead-letter queue."

  dimensions = {
    QueueName = var.dlq_name
  }
}

resource "aws_cloudwatch_metric_alarm" "submission_queue_backlog" {
  alarm_name          = "${var.name}-submission-queue-backlog"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 5
  metric_name         = "ApproximateNumberOfMessagesVisible"
  namespace           = "AWS/SQS"
  period              = 60
  statistic           = "Average"
  threshold           = 1000
  alarm_description   = "Submission queue backlog is high for several minutes."

  dimensions = {
    QueueName = var.queue_name
  }
}

resource "aws_cloudwatch_dashboard" "this" {
  dashboard_name = var.name

  dashboard_body = jsonencode({
    widgets = [
      {
        type = "metric"
        width = 12
        height = 6
        properties = {
          title = "SQS Submission Queue"
          view = "timeSeries"
          region = data.aws_region.current.name
          metrics = [
            ["AWS/SQS", "ApproximateNumberOfMessagesVisible", "QueueName", var.queue_name],
            [".", "ApproximateAgeOfOldestMessage", ".", "."]
          ]
        }
      },
      {
        type = "log"
        width = 12
        height = 6
        properties = {
          title = "Recent API Errors"
          region = data.aws_region.current.name
          query = "SOURCE '/aws/eks/${var.name}/api' | fields @timestamp, message | filter level = 'error' | sort @timestamp desc | limit 20"
        }
      }
    ]
  })
}

data "aws_region" "current" {}
