# Production Deployment

This repository is AWS production deployment focused. It includes the frontend, API, worker, infrastructure, and Kubernetes release definitions.

## Prerequisites

- AWS account with administrator bootstrap access
- Terraform `>= 1.6`
- AWS CLI v2
- kubectl
- Helm 3
- Docker
- A pre-created Terraform state S3 bucket and DynamoDB lock table
- An ACM certificate for the public hostname

## 1. Configure Terraform Backend

Edit:

```text
infra/terraform/envs/prod/backend.tf
```

Replace the placeholder state bucket and lock table names.

## 2. Provision AWS Infrastructure

```bash
cd infra/terraform/envs/prod
cp terraform.tfvars.example terraform.tfvars
terraform init
terraform plan
terraform apply
```

Terraform creates VPC, EKS, ECR repositories for frontend/API/worker, S3, SQS with DLQ, RDS PostgreSQL Multi-AZ, ElastiCache Redis, Cognito, IRSA roles, and CloudWatch resources.

## 3. Create Runtime Secret

```bash
kubectl create namespace hackathon
kubectl create secret generic platform-secrets \
  --namespace hackathon \
  --from-literal=DATABASE_URL='postgres://USER:PASSWORD@RDS_ENDPOINT:5432/hackathon' \
  --from-literal=REDIS_URL='rediss://REDIS_ENDPOINT:6379'
```

For production, prefer External Secrets Operator with AWS Secrets Manager.

## 4. Build and Push Images

```bash
export AWS_REGION=ap-south-1
export AWS_ACCOUNT_ID=123456789012
export IMAGE_TAG=$(git rev-parse --short HEAD)

make build-images
make push-images
```

This builds and pushes:

- `cloud-hackathon-platform-prod-frontend`
- `cloud-hackathon-platform-prod-api`
- `cloud-hackathon-platform-prod-worker`

Run migrations before deploying a new API version:

```bash
DATABASE_URL='postgres://USER:PASSWORD@RDS_ENDPOINT:5432/hackathon' npm run --prefix services/api migrate
```

Optional seed data for presentation:

```bash
DATABASE_URL='postgres://USER:PASSWORD@RDS_ENDPOINT:5432/hackathon' \
AWS_REGION=ap-south-1 \
S3_BUCKET='YOUR_S3_BUCKET_NAME' \
npm run --prefix services/api seed
```

## 5. Configure Cognito Values

Use Terraform outputs:

```bash
terraform output cognito_issuer
terraform output cognito_client_id
terraform output cognito_hosted_ui_domain
```

Set these in:

```text
deploy/helm/cloud-hackathon-platform/values-prod.yaml
```

Admin users must be added to the Cognito `Admins` group before they can create contests/problems.

## 6. Deploy to EKS

Edit:

```text
deploy/helm/cloud-hackathon-platform/values-prod.yaml
```

Then deploy:

```bash
aws eks update-kubeconfig --name cloud-hackathon-platform-prod --region ap-south-1

helm upgrade --install cloud-hackathon-platform ./deploy/helm/cloud-hackathon-platform \
  --namespace hackathon \
  --create-namespace \
  -f ./deploy/helm/cloud-hackathon-platform/values-prod.yaml \
  --set global.imageTag="$IMAGE_TAG" \
  --wait
```

## 7. Optional Observability Add-ons

The API exposes `/metrics`. If you install Prometheus Operator, enable:

```yaml
observability:
  serviceMonitor:
    enabled: true
```
