import "express-async-errors";
import cors from "cors";
import express from "express";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import { GetQueueAttributesCommand, SendMessageCommand } from "@aws-sdk/client-sqs";
import { v4 as uuidv4 } from "uuid";
import { bucket, queueUrl, s3, sqs } from "./aws.js";
import { query } from "./db.js";
import { redis } from "./redis.js";
import { log } from "./logger.js";
import { requireAuth, requireRole } from "./auth.js";
import { publishEvent, registerEventsRoute } from "./events.js";
import { metricsResponse, observeHttp, recordSubmission } from "./metrics.js";

const app = express();
const port = Number(process.env.API_PORT || 8080);

app.use(cors());
app.use(express.json({ limit: "256kb" }));
app.use(observeHttp);
app.use((req, _res, next) => {
  if (req.url === "/api") req.url = "/";
  if (req.url.startsWith("/api/")) req.url = req.url.slice(4);
  next();
});

app.get("/health", async (_req, res) => {
  res.json({ status: "ok", service: "api" });
});

app.get("/metrics", metricsResponse);

registerEventsRoute(app);

app.get("/ready", async (_req, res) => {
  await query("SELECT 1");
  await redis.ping();
  res.json({ status: "ready" });
});

app.get("/contests", async (_req, res) => {
  const contests = await query(
    "SELECT id, title, description, starts_at, ends_at FROM contests ORDER BY starts_at DESC"
  );
  res.json(contests);
});

app.get("/me", requireAuth, async (req, res) => {
  res.json(req.user);
});

app.post("/users", requireAuth, requireRole("ADMIN"), async (req, res) => {
  const { name, email, role = "PARTICIPANT" } = req.body;
  if (!name || !email) {
    res.status(400).json({ error: "name and email are required" });
    return;
  }

  const [user] = await query(
    `INSERT INTO users (name, email, role)
     VALUES ($1, $2, $3)
     ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, role = EXCLUDED.role
     RETURNING id, name, email, role`,
    [name, email, role]
  );
  res.status(201).json(user);
});

app.get("/users/:userId", requireAuth, async (req, res) => {
  if (req.user.role !== "ADMIN" && req.user.id !== req.params.userId) {
    res.status(403).json({ error: "Insufficient permissions" });
    return;
  }
  const [user] = await query("SELECT id, name, email, role FROM users WHERE id = $1", [req.params.userId]);
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json(user);
});

app.get("/contests/:contestId/problems", async (req, res) => {
  const problems = await query(
    "SELECT id, title, statement, time_limit_ms, memory_limit_mb FROM problems WHERE contest_id = $1 ORDER BY title",
    [req.params.contestId]
  );
  res.json(problems);
});

app.post("/admin/contests", requireAuth, requireRole("ADMIN"), async (req, res) => {
  const { title, description, startsAt, endsAt } = req.body;
  if (!title || !description || !startsAt || !endsAt) {
    res.status(400).json({ error: "title, description, startsAt, and endsAt are required" });
    return;
  }

  const [contest] = await query(
    `INSERT INTO contests (title, description, starts_at, ends_at)
     VALUES ($1, $2, $3, $4)
     RETURNING id, title, description, starts_at, ends_at`,
    [title, description, startsAt, endsAt]
  );
  await publishEvent("contest.created", { contestId: contest.id });
  res.status(201).json(contest);
});

app.post("/admin/problems", requireAuth, requireRole("ADMIN"), async (req, res) => {
  const { contestId, title, statement, timeLimitMs = 2000, memoryLimitMb = 256, tests } = req.body;
  if (!contestId || !title || !statement || !Array.isArray(tests) || tests.length === 0) {
    res.status(400).json({ error: "contestId, title, statement, and non-empty tests array are required" });
    return;
  }

  for (const test of tests) {
    if (typeof test.input !== "string" || typeof test.output !== "string") {
      res.status(400).json({ error: "Each test must include string input and output" });
      return;
    }
  }

  const problemId = uuidv4();
  const testsS3Key = `problems/${problemId}/tests.json`;
  await s3.send(new PutObjectCommand({
    Bucket: bucket,
    Key: testsS3Key,
    Body: JSON.stringify(tests),
    ContentType: "application/json"
  }));

  const [problem] = await query(
    `INSERT INTO problems (id, contest_id, title, statement, time_limit_ms, memory_limit_mb, tests_s3_key)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id, contest_id, title, statement, time_limit_ms, memory_limit_mb`,
    [problemId, contestId, title, statement, timeLimitMs, memoryLimitMb, testsS3Key]
  );
  await publishEvent("problem.created", { contestId, problemId: problem.id });
  res.status(201).json(problem);
});

app.get("/contests/:contestId/leaderboard", async (req, res) => {
  const key = `leaderboard:${req.params.contestId}`;
  const cached = await redis.zrevrange(key, 0, 49, "WITHSCORES");
  if (cached.length > 0) {
    const leaderboard = [];
    for (let i = 0; i < cached.length; i += 2) {
      leaderboard.push({ userId: cached[i], score: Number(cached[i + 1]) });
    }
    const users = await query("SELECT id, name FROM users WHERE id = ANY($1)", [leaderboard.map((r) => r.userId)]);
    const names = new Map(users.map((u) => [u.id, u.name]));
    res.json(leaderboard.map((r, idx) => ({ rank: idx + 1, name: names.get(r.userId) || r.userId, ...r })));
    return;
  }

  const rows = await query(
    `SELECT s.user_id, u.name, SUM(best_score) AS score
     FROM (
       SELECT user_id, problem_id, MAX(score) AS best_score
       FROM submissions
       WHERE contest_id = $1
       GROUP BY user_id, problem_id
     ) s
     JOIN users u ON u.id = s.user_id
     GROUP BY s.user_id, u.name
     ORDER BY score DESC`,
    [req.params.contestId]
  );
  res.json(rows.map((r, idx) => ({ rank: idx + 1, userId: r.user_id, name: r.name, score: Number(r.score) })));
});

app.get("/platform/stats", requireAuth, async (_req, res) => {
  const [counts] = await query(
    `SELECT
       (SELECT COUNT(*)::int FROM contests) AS contests,
       (SELECT COUNT(*)::int FROM problems) AS problems,
       (SELECT COUNT(*)::int FROM submissions) AS submissions,
       (SELECT COUNT(*)::int FROM submissions WHERE status = 'ACCEPTED') AS accepted,
       (SELECT COUNT(*)::int FROM submissions WHERE status IN ('QUEUED', 'RUNNING')) AS pending`
  );
  const queue = await sqs.send(new GetQueueAttributesCommand({
    QueueUrl: queueUrl,
    AttributeNames: ["ApproximateNumberOfMessages", "ApproximateNumberOfMessagesNotVisible"]
  }));
  res.json({
    ...counts,
    queueVisible: Number(queue.Attributes?.ApproximateNumberOfMessages || 0),
    queueInFlight: Number(queue.Attributes?.ApproximateNumberOfMessagesNotVisible || 0)
  });
});

app.get("/submissions/:submissionId", requireAuth, async (req, res) => {
  const [submission] = await query("SELECT * FROM submissions WHERE id = $1", [req.params.submissionId]);
  if (!submission) {
    res.status(404).json({ error: "Submission not found" });
    return;
  }
  if (req.user.role !== "ADMIN" && submission.user_id !== req.user.id) {
    res.status(403).json({ error: "Insufficient permissions" });
    return;
  }
  res.json(submission);
});

app.get("/submissions", requireAuth, async (req, res) => {
  const { contestId, userId } = req.query;
  if (!contestId) {
    res.status(400).json({ error: "contestId is required" });
    return;
  }

  const effectiveUserId = req.user.role === "ADMIN" ? userId : req.user.id;
  const params = [contestId];
  let where = "WHERE s.contest_id = $1";
  if (effectiveUserId) {
    params.push(effectiveUserId);
    where += " AND s.user_id = $2";
  }

  const rows = await query(
    `SELECT s.id, s.user_id, u.name, s.problem_id, p.title AS problem_title, s.language,
            s.status, s.score, s.verdict, s.runtime_ms, s.created_at, s.judged_at
     FROM submissions s
     JOIN users u ON u.id = s.user_id
     JOIN problems p ON p.id = s.problem_id
     ${where}
     ORDER BY s.created_at DESC
     LIMIT 100`,
    params
  );
  res.json(rows);
});

app.post("/admin/submissions/:submissionId/rejudge", requireAuth, requireRole("ADMIN"), async (req, res) => {
  const [submission] = await query(
    "UPDATE submissions SET status = 'QUEUED', verdict = NULL, score = 0, runtime_ms = NULL, stderr = NULL, judged_at = NULL WHERE id = $1 RETURNING id, contest_id, user_id",
    [req.params.submissionId]
  );
  if (!submission) {
    res.status(404).json({ error: "Submission not found" });
    return;
  }
  await sqs.send(new SendMessageCommand({
    QueueUrl: queueUrl,
    MessageBody: JSON.stringify({ submissionId: submission.id, rejudge: true })
  }));
  await publishEvent("submission.requeued", {
    submissionId: submission.id,
    contestId: submission.contest_id,
    userId: submission.user_id
  });
  res.status(202).json({ submissionId: submission.id, status: "QUEUED" });
});

app.post("/submissions", requireAuth, async (req, res) => {
  const { contestId, problemId, language, code } = req.body;
  const userId = req.user.id;

  if (!contestId || !problemId || !language || !code) {
    res.status(400).json({ error: "contestId, problemId, language, and code are required" });
    return;
  }

  if (!["python", "javascript"].includes(language)) {
    res.status(400).json({ error: "Only python and javascript are enabled" });
    return;
  }

  const [contest] = await query(
    "SELECT id FROM contests WHERE id = $1 AND now() BETWEEN starts_at AND ends_at",
    [contestId]
  );
  if (!contest) {
    res.status(400).json({ error: "Contest is not active" });
    return;
  }

  const [problem] = await query(
    "SELECT id FROM problems WHERE id = $1 AND contest_id = $2",
    [problemId, contestId]
  );
  if (!problem) {
    res.status(400).json({ error: "Problem does not belong to contest" });
    return;
  }

  const submissionId = uuidv4();
  const extension = language === "python" ? "py" : "js";
  const s3Key = `submissions/${submissionId}/main.${extension}`;

  await s3.send(new PutObjectCommand({
    Bucket: bucket,
    Key: s3Key,
    Body: code,
    ContentType: "text/plain"
  }));

  await query(
    `INSERT INTO submissions (id, user_id, contest_id, problem_id, language, s3_key, status)
     VALUES ($1, $2, $3, $4, $5, $6, 'QUEUED')`,
    [submissionId, userId, contestId, problemId, language, s3Key]
  );

  await sqs.send(new SendMessageCommand({
    QueueUrl: queueUrl,
    MessageBody: JSON.stringify({ submissionId })
  }));

  recordSubmission(contestId, language);
  await publishEvent("submission.queued", { submissionId, contestId, userId });
  res.status(202).json({ submissionId, status: "QUEUED" });
});

app.use((error, _req, res, _next) => {
  log("error", "request failed", { error: error.message, stack: error.stack });
  res.status(500).json({ error: "Internal server error" });
});

app.listen(port, () => {
  log("info", "api listening", { port });
});
