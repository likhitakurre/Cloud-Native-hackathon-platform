import { PutObjectCommand } from "@aws-sdk/client-s3";
import { v4 as uuidv4 } from "uuid";
import { bucket, s3 } from "./aws.js";
import { pool, query } from "./db.js";

const contestId = "22222222-2222-2222-2222-222222222222";
const problemId = "33333333-3333-3333-3333-333333333333";

async function main() {
  const testsKey = `problems/${problemId}/tests.json`;
  await s3.send(new PutObjectCommand({
    Bucket: bucket,
    Key: testsKey,
    ContentType: "application/json",
    Body: JSON.stringify([
      { input: "2\n", output: "4\n" },
      { input: "7\n", output: "14\n" },
      { input: "123\n", output: "246\n" }
    ])
  }));

  await query(
    `INSERT INTO contests (id, title, description, starts_at, ends_at)
     VALUES ($1, 'End Term Cloud Sprint', 'Presentation-ready contest for demonstrating the AWS/EKS judging pipeline.', now() - interval '1 hour', now() + interval '7 days')
     ON CONFLICT (id) DO NOTHING`,
    [contestId]
  );

  await query(
    `INSERT INTO problems (id, contest_id, title, statement, time_limit_ms, memory_limit_mb, tests_s3_key)
     VALUES ($1, $2, 'Double It', 'Read one integer n and print 2*n.', 2000, 256, $3)
     ON CONFLICT (id) DO NOTHING`,
    [problemId, contestId, testsKey]
  );

  const adminSubject = `seed-admin-${uuidv4()}`;
  await query(
    `INSERT INTO users (external_subject, name, email, role)
     VALUES ($1, 'Presentation Admin', 'admin@example.com', 'ADMIN')
     ON CONFLICT (email) DO NOTHING`,
    [adminSubject]
  );

  console.log(JSON.stringify({ level: "info", message: "seed data ready", contestId, problemId }));
}

main()
  .catch((error) => {
    console.error(JSON.stringify({ level: "error", message: "seed failed", error: error.message }));
    process.exitCode = 1;
  })
  .finally(() => pool.end());

