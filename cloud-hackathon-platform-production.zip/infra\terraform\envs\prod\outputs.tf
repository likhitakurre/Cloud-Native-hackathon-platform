output "cluster_name" {
  value = module.eks.cluster_name
}

output "cluster_endpoint" {
  value = module.eks.cluster_endpoint
}

output "ecr_repository_urls" {
  value = module.ecr.repository_urls
}

output "submissions_bucket_name" {
  value = module.storage.submissions_bucket_name
}

output "sqs_queue_url" {
  value = module.queue.queue_url
}

output "rds_endpoint" {
  value     = module.database.endpoint
  sensitive = true
}

output "database_secret_arn" {
  value = module.database.secret_arn
}

output "redis_endpoint" {
  value = module.cache.endpoint
}

output "api_role_arn" {
  value = module.irsa.api_role_arn
}

output "worker_role_arn" {
  value = module.irsa.worker_role_arn
}

output "cognito_user_pool_id" {
  value = module.auth.user_pool_id
}

output "cognito_client_id" {
  value = module.auth.client_id
}

output "cognito_issuer" {
  value = module.auth.issuer
}

output "cognito_hosted_ui_domain" {
  value = module.auth.hosted_ui_domain
}
