import { redis } from "./redis.js";

const channel = "platform-events";
const subscriber = redis.duplicate();
const clients = new Set();

subscriber.subscribe(channel);
subscriber.on("message", (_channel, message) => {
  for (const client of clients) {
    client.write(`event: platform\n`);
    client.write(`data: ${message}\n\n`);
  }
});

export function registerEventsRoute(app) {
  app.get("/events", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();
    res.write("event: connected\n");
    res.write("data: {\"status\":\"connected\"}\n\n");
    clients.add(res);
    req.on("close", () => clients.delete(res));
  });
}

export async function publishEvent(type, payload) {
  await redis.publish(channel, JSON.stringify({ type, payload, timestamp: new Date().toISOString() }));
}

