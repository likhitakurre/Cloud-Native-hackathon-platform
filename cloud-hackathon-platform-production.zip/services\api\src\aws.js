import { S3Client } from "@aws-sdk/client-s3";
import { SQSClient } from "@aws-sdk/client-sqs";

const endpoint = process.env.AWS_ENDPOINT;
const region = process.env.AWS_REGION || "ap-south-1";

export const s3 = new S3Client({
  region,
  endpoint,
  forcePathStyle: Boolean(endpoint)
});

export const sqs = new SQSClient({
  region,
  endpoint
});

export const bucket = process.env.S3_BUCKET || "hackathon-platform";
export const queueUrl = process.env.SQS_QUEUE_URL;

