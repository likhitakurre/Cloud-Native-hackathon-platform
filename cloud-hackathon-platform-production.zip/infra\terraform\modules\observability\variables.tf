variable "name" { type = string }
variable "log_retention_days" { type = number }
variable "dlq_name" { type = string }
variable "queue_name" { type = string }
