resource "aws_sqs_queue" "dlq" {
  name                      = "${var.name}-submissions-dlq"
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled   = true
}

resource "aws_sqs_queue" "submissions" {
  name                       = "${var.name}-submissions"
  visibility_timeout_seconds = var.visibility_timeout_seconds
  message_retention_seconds  = 1209600
  sqs_managed_sse_enabled    = true

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.dlq.arn
    maxReceiveCount     = 5
  })
}

