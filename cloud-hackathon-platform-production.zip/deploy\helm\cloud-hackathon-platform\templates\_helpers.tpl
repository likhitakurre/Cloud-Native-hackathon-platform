{{- define "platform.name" -}}
cloud-hackathon-platform
{{- end -}}

{{- define "platform.labels" -}}
app.kubernetes.io/name: {{ include "platform.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "platform.image" -}}
{{- if .root.Values.global.imageRegistry -}}
{{ .root.Values.global.imageRegistry }}/{{ .repository }}:{{ .root.Values.global.imageTag }}
{{- else -}}
{{ .repository }}:{{ .root.Values.global.imageTag }}
{{- end -}}
{{- end -}}

