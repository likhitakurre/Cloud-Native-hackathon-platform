import { DeleteMessageCommand, ReceiveMessageCommand } from "@aws-sdk/client-sqs";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import Redis from "ioredis";
import { bucket, queueUrl, s3, sqs } from "./aws.js";
import { query } from "./db.js";
import { runSubmission } from "./sandbox.js";
import { log } from "./logger.js";

const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379");
const concurrency = Number(process.env.WORKER_CONCURRENCY || 2);

async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks).toString("utf8");
}

function normalize(value) {
  return value.replace(/\r\n/g, "\n").trimEnd();
}

async function scoreUser(contestId, userId) {
  const rows = await query(
    `SELECT COALESCE(SUM(best_score), 0) AS score
     FROM (
       SELECT problem_id, MAX(score) AS best_score
       FROM submissions
       WHERE contest_id = $1 AND user_id = $2
       GROUP BY problem_id
     ) best`,
    [contestId, userId]
  );
  const score = Number(rows[0].score);
  await redis.zadd(`leaderboard:${contestId}`, score, userId);
  return score;
}

async function publishEvent(type, payload) {
  await redis.publish("platform-events", JSON.stringify({ type, payload, timestamp: new Date().toISOString() }));
}

async function judgeSubmission(submissionId) {
  log("info", "judging submission", { submissionId });
  const [submission] = await query(
    `SELECT s.*, p.tests_s3_key
     FROM submissions s
     JOIN problems p ON p.id = s.problem_id
     WHERE s.id = $1`,
    [submissionId]
  );

  if (!submission || ["ACCEPTED", "WRONG_ANSWER", "TIME_LIMIT_EXCEEDED", "RUNTIME_ERROR"].includes(submission.status)) {
    return;
  }

  await query("UPDATE submissions SET status = 'RUNNING' WHERE id = $1", [submissionId]);
  await publishEvent("submission.running", {
    submissionId,
    contestId: submission.contest_id,
    userId: submission.user_id
  });

  const object = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: submission.s3_key }));
  const source = await streamToString(object.Body);
  const testsObject = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: submission.tests_s3_key }));
  const tests = JSON.parse(await streamToString(testsObject.Body));

  let finalVerdict = "ACCEPTED";
  let runtimeMs = 0;
  let stderr = "";

  for (const test of tests) {
    const result = await runSubmission({
      language: submission.language,
      source,
      input: test.input
    });

    runtimeMs += result.runtimeMs;
    stderr = result.stderr || stderr;

    if (result.verdict !== "OK") {
      finalVerdict = result.verdict;
      break;
    }

    if (normalize(result.stdout) !== normalize(test.output)) {
      finalVerdict = "WRONG_ANSWER";
      break;
    }
  }

  const score = finalVerdict === "ACCEPTED" ? 100 : 0;
  await query(
    `UPDATE submissions
     SET status = $2, verdict = $2, score = $3, runtime_ms = $4, stderr = $5, judged_at = now()
     WHERE id = $1`,
    [submissionId, finalVerdict, score, runtimeMs, stderr.slice(0, 4000)]
  );
  const userScore = await scoreUser(submission.contest_id, submission.user_id);
  await publishEvent("submission.judged", {
    submissionId,
    contestId: submission.contest_id,
    userId: submission.user_id,
    verdict: finalVerdict,
    score,
    userScore
  });
  log("info", "submission judged", { submissionId, verdict: finalVerdict, score });
}

async function pollOnce() {
  const response = await sqs.send(new ReceiveMessageCommand({
    QueueUrl: queueUrl,
    MaxNumberOfMessages: Math.min(concurrency, 10),
    WaitTimeSeconds: 10,
    VisibilityTimeout: 30
  }));

  await Promise.all((response.Messages || []).map(async (message) => {
    try {
      const body = JSON.parse(message.Body);
      await judgeSubmission(body.submissionId);
      await sqs.send(new DeleteMessageCommand({ QueueUrl: queueUrl, ReceiptHandle: message.ReceiptHandle }));
    } catch (error) {
      log("error", "judge failed", { error: error.message, stack: error.stack });
    }
  }));
}

async function main() {
  log("info", "worker started", { concurrency });
  while (true) {
    await pollOnce();
  }
}

main().catch((error) => {
  log("error", "worker crashed", { error: error.message, stack: error.stack });
  process.exit(1);
});
