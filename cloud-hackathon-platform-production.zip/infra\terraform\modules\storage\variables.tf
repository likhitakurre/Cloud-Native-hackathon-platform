variable "name" { type = string }

